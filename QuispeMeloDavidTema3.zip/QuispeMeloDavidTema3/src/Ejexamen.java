import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ejexamen {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
	        int opcion;
	        boolean salir = false;
	        String []participantes = new String [6];
	        String[]tentadores= new String [6];
	        double[][] tentacion = new double[6][6];

	        do {
	            System.out.println("\n   --- SISTEMA DE GESTIÓN DE ALUMNOS Y NOTAS ---");
	            System.out.println("1.  Llegada a la villa");
	            System.out.println("2.  ¡Hay más imágenes!");
	            System.out.println("3. Hoguera de Confrontación");
	            System.out.println("4.  La luz de la tentación");
	            System.out.println("5. “Montoya, por favor");

	            opcion = leerint("Selecciona una opción: ");

	            switch (opcion) {
	                case 1:
	                    llegadavilla(tentacion,participantes,tentadores);
	                    break;
	                case 2:
	                    Hayimagenes(tentacion, participantes,  tentadores);
	                    break;
	                case 3:
					
					Hogueraconfrontacion( tentacion, participantes,  tentadores);
	                    break;
	                case 4:
	                    
	                    break;
	              
	               
	                case 5:
	                    System.out.println("Montoya, por favor\r\n"
	                    		+ "Nos vemos en la próxima edición");
	                    salir = true;
	                    break;
	                default:
	                    System.out.println("Opción inválida. Intenta de nuevo.");
	            }

	        } while (!salir);
	        
	}
	public static void llegadavilla(double[][] tentacion, String []participantes, String []tentadores) throws IOException {
		System.out.println("--- LLEGADA A LA VILLA ---");
		System.out.println("Introduce los nombres de los 6 PARTICIPANTES:");
		for(int i=0; i<participantes.length; i++) {
			String nombre;
			do {
				
				nombre = leerString("Participante" + (i+1));
			}while(nombre.isEmpty() || hayDuplicados(nombre, participantes,tentadores));
			
			participantes[i] = nombre;
		}
		System.out.println("Introduce los nombres de los 6 TENTADORES:");
		for(int i=0; i<tentadores.length; i++) {
			String nombre;
			do {
				nombre = leerString("Tentador" + (i+1));
			}while(nombre.isEmpty() || hayDuplicados(nombre, participantes,tentadores));
			
			tentadores[i] = nombre;
		}
		for(int f=0; f<tentacion.length; f++) {
			for(int c=0; c<tentacion[f].length; c++)
				tentacion[f][c] = 0;
			
		}
		
		
	
		System.out.println("¡Todos los participantes y tentadores han\r\n"
				+ "llegado a la villa!");
	}
	
	public static boolean hayDuplicados(String nombre, String[] participantes,String[] tentadores) {
		boolean hayDuplicados = false;
		for(int i=0; i<participantes.length; i++)
			if(participantes[i] != null) {
				if(participantes[i].equalsIgnoreCase(nombre)) {
					hayDuplicados = true;
					System.out.println("El nombre esta duplicado");
				}
			}else if(tentadores[i] != null) {
				if(tentadores[i].equalsIgnoreCase(nombre)) {
					hayDuplicados = true;
					System.out.println("El nombre esta duplicado");
				}
			}
			
		
		return hayDuplicados;
	}
	public static void  Hayimagenes(double[][] tentacion, String[] participantes,String[] tentadores) throws NumberFormatException, IOException {
		System.out.println("--- ¡HAY MÁS IMÁGENES! ---");
		for(int f=0; f<participantes.length; f++) {
			System.out.print("Tentadores" + f + ". " + participantes[f]);
		for(int c=0; c<tentadores.length; c++) {
			System.out.print("Participantes"+c + ". " + tentadores[c]);
			
		int posparticipante = -1;
		boolean activo;
		do {
			activo = true;
			posparticipante = leerint("Introduce el índice del participante (0-5): ");
			if(posparticipante<0 || posparticipante>5) {
				System.out.println("El numero introducido no esta entre 0 y 5");
			}
				
		}while(posparticipante<0 ||  posparticipante>5 || activo == false);
		
		int postentadores = -1;
		do {
			postentadores = leerint("Introduce el índice del tentado (0-5):");
			if(postentadores<1 || postentadores>5) 
				System.out.println("El numero introducido no esta entre 1 y 5");
				
		}while(postentadores<1 ||  postentadores>5);
		
		int gradotentacion = -1;
		do {
			gradotentacion = leerint("Introduce el grado de tentación a sumar: ");
			if(gradotentacion<0 || gradotentacion>100) 
				System.out.println("El numero introducido no esta entre 0 y 100");
				
		}while(gradotentacion<0 ||  gradotentacion>100);
		
		tentacion[posparticipante][postentadores-1] = gradotentacion;
		System.out.println("¡Tentación actualizada! " + participantes[posparticipante] + " y " + tentadores[postentadores]+ " ahora tienen un nivel de "+gradotentacion);
		}
		
		}
	}
		public static void Hogueraconfrontacion(double[][] tentacion, String[] participantes, String[] tentadores) {
			System.out.println("--- HOGUERA DE CONFRONTACIÓN ---");
			
			System.out.print("\t\t");
			for(int i=0; i<tentacion[0].length; i++) {
				System.out.print("J" + (i+1) + "\t\t");
			}
			System.out.println("TOTAL");
			
			for(int f=0; f<tentacion.length; f++) {
				System.out.print(tentadores[f] + "\t\t");
				int total = 0;
				for(int c=0; c<tentacion[f].length; c++) {
					System.out.print(tentacion[f][c] + "\t\t" );
					total += tentacion[f][c];
				}
				System.out.println("tentación total de "+ total);
			}
			
		
			}
		public static void opcion4(int[][] tentacion, String[] participantes, int[] tentadores) throws NumberFormatException, IOException {
	        System.out.println("\n--- LA LUZ DE LA TENTACIÓN ---");

	     
	        int umbral = -1;
	        do {
	            umbral = leerint("Introduce el índice del equipo (0-100): ");
	            if (umbral < 0 || umbral >100) {
	                System.out.println("El número introducido no está entre 0 y 100");
	            }
	        } while (umbral < 0 || umbral >100);

		}
		
	
	
		   public static int  leerint(String mensaje) throws NumberFormatException, IOException {
				BufferedReader leer= new BufferedReader(new InputStreamReader(System.in));
				System.out.println(mensaje);
				int num = Integer.parseInt(leer.readLine());
				return num;
		}
		   public static String leerString(String mensaje) throws IOException {
				BufferedReader leer = new BufferedReader(new InputStreamReader(System.in));
				System.out.print(mensaje);
				return leer.readLine();
			}
}
